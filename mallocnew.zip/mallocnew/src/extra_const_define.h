//
//  Header.h
//  libmalloc
//
//  Created by wqa on 2018/11/30.
//

#ifndef EXTRA_CONST_DEFINE_H
#define EXTRA_CONST_DEFINE_H

#define	_COMM_PAGE_PHYSICAL_CPUS		(_COMM_PAGE_START_ADDRESS+0x035)	// uint8_t number of physical CPUs
#define _COMM_PAGE64_BASE_ADDRESS		(0xfffffff0001fc000ULL) /* Just below the kernel, safely in TTBR1 */
#define _COMM_PAGE_START_ADDRESS		_COMM_PAGE64_BASE_ADDRESS
#define _COMM_PRIV_PAGE64_BASE_ADDRESS	(_COMM_PAGE64_BASE_ADDRESS - (4096))
#define	_COMM_PAGE_MEMORY_SIZE			(_COMM_PAGE_START_ADDRESS+0x038)	// uint64_t max memory size */
#define _COMM_PAGE_NCPUS			(_COMM_PAGE_START_ADDRESS+0x022)	// uint8_t number of configured CPUs
#define	_COMM_PAGE_LOGICAL_CPUS			(_COMM_PAGE_START_ADDRESS+0x036)	// uint8_t number of logical CPUs
#define DEBUG_MALLOC 	1

#ifndef __LP64__
#define __LP64__
#define  __LP64__ 1
#endif

#define NOTE_VM_PRESSURE			0x80000000              /* will react on memory pressure */
#define NOTE_VM_PRESSURE_TERMINATE		0x40000000              /* will quit on memory pressure, possibly after cleaning up dirty state */
#define NOTE_VM_PRESSURE_SUDDEN_TERMINATE	0x20000000		/* will quit immediately on memory pressure */
#define NOTE_VM_ERROR				0x10000000              /* there was an error */

/*
 * data/hint fflags for EVFILT_MEMORYSTATUS, shared with userspace.
 */
#define NOTE_MEMORYSTATUS_PRESSURE_NORMAL	0x00000001	/* system memory pressure has returned to normal */
#define NOTE_MEMORYSTATUS_PRESSURE_WARN		0x00000002	/* system memory pressure has changed to the warning state */
#define NOTE_MEMORYSTATUS_PRESSURE_CRITICAL	0x00000004	/* system memory pressure has changed to the critical state */
#define NOTE_MEMORYSTATUS_LOW_SWAP		0x00000008	/* system is in a low-swap state */
#define NOTE_MEMORYSTATUS_PROC_LIMIT_WARN	0x00000010	/* process memory limit has hit a warning state */
#define NOTE_MEMORYSTATUS_PROC_LIMIT_CRITICAL	0x00000020	/* process memory limit has hit a critical state - soft limit */
#define NOTE_MEMORYSTATUS_MSL_STATUS   0xf0000000      /* bits used to request change to process MSL status */

#endif /* EXTRA_CONST_DEFINE_H */
